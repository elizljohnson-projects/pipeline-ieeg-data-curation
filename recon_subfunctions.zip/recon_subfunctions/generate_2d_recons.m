function generate_2d_recons(cfg, elec)

% --------------------------------------------------------
% GENERATE_2D_RECONS creates 2D recons of depths by plotting coronal slices
% of the MRI until all electrodes are plotted and creates 2D recons of
% surface electrodes by plotting them on the cortical surface and taking
% pictures from all 6 major angles
%   
% Use as:
%   plot_depth_slices(cfg, elec)
%   where 
%       elec        = structure, original elec structure with a .label and .elecpos field
%
% The Configuration may contain the following inputs
%  ptid             = string, patient ID
%  imagesdir        = string, directory where you want the 2D Recons saved
%  electype         = 'surface', 'depths', or 'all', which types of
%                     electrodes in elec that you want to make 2D Recons
%  display          = 'yes' or 'no', whether or not you want the figures to
%                     be displayed on the screen after they are generated (default = 'no')
%  
%
% If cfg.electype = 'depths' then the configuration should contain the
% following inputs
%   mri             = structure, mri corresponding to the elec structure
%   radius          = scalar, how many mm away an electrode can be in order to be
%                     depicted in a given MRI slice (default = 2)
%
% If cfg.electype = 'surface' then the configuration should contain the
% following inputs
%  cortex_lh        = structure, cortical mesh of the left hemisphere
%  cortex_rh        = structure, cortical mesh of the right hemisphere
%  hullpos          = Nx3 array of positions on the smoothed cortical
%                     hull mesh (to be passed to describe_elec for 
%                     identifying electrodes as surface or depths)

%
% FUTURE WORK: 
% fix the cfg.method 'all' (specifically the naming of the
%   depth plots and the numbering of the grid electrodes)
% add a key to the depth slices showing where on the cortex the slice was
%   taken
%

% Get the inputs
patient_id = ft_getopt(cfg, 'ptid');
mri = ft_getopt(cfg, 'mri');
cortex_lh = ft_getopt(cfg, 'cortex_lh');
cortex_rh = ft_getopt(cfg, 'cortex_rh');
hullpos = ft_getopt(cfg, 'hullpos', []);
electype = ft_getopt(cfg, 'electype', 'all');
method = ft_getopt(cfg, 'method', 'ind');
radius = ft_getopt(cfg, 'radius', 2);
display = ft_getopt(cfg, 'display', 'no');
imagesdir = ft_getopt(cfg, 'imagesdir');

if isempty(patient_id)
  error('no patient ID specified, enter cfg.ptid')
end
if (strcmp(electype, 'depths') || strcmp(electype, 'all')) && isempty(mri)
  error('No MRI specified, to plot depths, enter cfg.mri')
end
if (strcmp(electype, 'surface') || strcmp(electype, 'all')) && (isempty(cortex_lh) || isempty(cortex_rh))
  error('No cortical mesh specified, to plot surface electrodes, enter cfg.cortex_lh and cfg.cortex_rh')
end
if (strcmp(electype, 'surface') || strcmp(electype, 'all')) && isempty(mri)
  error('No cortical mesh specified, to plot depths, enter cfg.cortex_lh and cfg.cortex_rh')
end

if ~exist(imagesdir)
  mkdir(imagesdir);
end

elec_og = elec;

% cfg = [];
% cfg.hullpos = hullpos;
% if ~isfield(elec_og, 'surface')
%   elec_og = describe_elec(cfg, elec_og);
% end

if strcmp(electype, 'depth') || strcmp(electype, 'all')
  elec = {};
  
  % Limit elec to all depths or the depths for a particular tract depending on the method
  if strcmp(method, 'all')
    depthnames = elec.depths; %{};
    for n = 1:numel(elec_og.depths)
      depthnames = [depthnames; elec_og.depths{n}];
    end
    cfg = [];
    cfg.channel = depthnames;
    elec{1} = select_elec(cfg, elec_og);
  elseif strcmp(method, 'ind') % create a cell array of elec structures: 1 for each depth tract
    for n = 1:numel(elec_og.depths)
      cfg = [];
      cfg.channel = elec_og.depths{n};
      elec{n} = select_elec(cfg, elec_og);
    end
  end
  
  for n = 1:numel(elec)
    % Search through the coronal sections defined by the anterior and posterior
    % limits of the depth electrode positions
    lim_a = round(max(elec{n}.elecpos(:,2))); lim_p = round(min(elec{n}.elecpos(:,2)));
    slicepos_potent = lim_p:lim_a; % potential slices
    d_slicepos_potent = NaN(size(elec{n}.elecpos, 1), length(slicepos_potent)); % pre-allocate matrix to store distances between each slice and each electrode
    d_within_range = NaN(size(elec{n}.elecpos, 1), length(slicepos_potent)); % pre-allocate matrix to store whether a given slice is within 2mm of a given electrode
    for s = 1:length(slicepos_potent) % potential slice loop
      for e = 1:size(elec{n}.elecpos, 1) % electrode loop
        d_slicepos_potent(e, s) = abs(elec{n}.elecpos(e, 2) - slicepos_potent(s));
        % identify whether this sections is within 2mm of this electrode
        if d_slicepos_potent(e, s) < 2
          d_within_range(e, s) = 1;
        else
          d_within_range(e, s) = 0;
        end
      end % end electrode loop
    end % end slice loop
    
    % Identify which of those sections has multiple electrodes within 2 mm and
    % plot those sections
    while any(any(d_within_range)) % while there are still electrodes that need to be plotted
      elecs_per_slice = sum(d_within_range);
      % plot the slice that's within 2mm of the most electrodes first
      best_slice = find(elecs_per_slice == max(elecs_per_slice));
      best_slice = best_slice(1);
      slicepos = slicepos_potent(best_slice);
      
      % create a temporary elec structure of just the electrodes that are
      % within 2mm of this slice
      elecs2plot = elec{n}.label(find(d_within_range(:, best_slice)));
%       elecs2plot = {};
%       for n_tmp = 1:size(tmp,1)
%         elecs2plot{end+1} = char(tmp{n_tmp}(1));
%       end
      cfg = [];
      cfg.channel = elecs2plot;
      elec_tmp = select_elec(cfg, elec_og); %{n});
      
      % plot this slice through the MRI
      figure;
      ft_plot_slice(mri.anatomy, 'transform', mri.transform, ...
        'location', [0 slicepos 0], ...
        'orientation', [0 1 0]);
      
      % adjust the electrode positions so that they are just in front of the slice
      elec_tmp.chanpos(:,2) = slicepos+1;
      
      % plot white circles with a black outline for the electrodes
      
      % generate circle points
      angles = linspace(0,2*pi,50);
      x = cos(angles)';
      y = sin(angles)';
      slicedim = slicepos*ones(length(angles),1);
      
      % Determine points along outermost circle
      xo = radius*x;
      yo = radius*y;
      xi = radius*.8*x;
      yi = radius*.8*y;
      
      hold on
      for e = 1:size(elec_tmp.elecpos, 1)
        fill3(elec_tmp.elecpos(e,1)+xo, slicedim, elec_tmp.elecpos(e,3)+yo, 'r') % inner circle
        fill3([elec_tmp.elecpos(e,1)+xo; elec_tmp.elecpos(e,1)+xi], [slicedim; slicedim], [elec_tmp.elecpos(e,3)+yo; elec_tmp.elecpos(e,3)+yi], 'b') % outer circle
      end
      
      view([-180 0]); axis off;
      
      % Get the names and numbers of these electrodes for the filename
      ElecStrs = {};
      ElecNrs = [];
      for e = 1:numel(elec_tmp.label) % electrode loop
        ElecStrs{e,1} = regexprep(elec_tmp.label{e}, '\d+(?:_(?=\d))?', ''); % without electrode numbers
        ElecNrs(e) = str2double(regexp(elec_tmp.label{e},'-?\d+\.?\d*|-?\d*\.?\d+', 'match')); % without electrode strings
      end
      
      % Save this Figure in the 2D Recon Directory
      % Make a directory for Depths if it doesn't already exist
      if ~exist([imagesdir 'Depths/'])
        mkdir([imagesdir 'Depths/']);
      end
      
      if strcmp(method, 'ind')
        tractname = [elec{n}.label{1} '_' elec{n}.label{end}]; %char(unique(ElecStrs));
        % Make a directory for this depth tract if it doesn't already exist
        if ~exist([imagesdir 'Depths/' tractname '/'])
          mkdir([imagesdir 'Depths/' tractname '/']);
        end
        
        % Figure name should be derived from name of this individual depth
        % tract and the numbers
        if numel(ElecNrs) > 1
          min_num = min(ElecNrs);
          max_num = max(ElecNrs);
          
          hgexport(gcf, [imagesdir 'Depths/'  tractname '/' patient_id '_' num2str(min_num) '-' num2str(max_num)]);
        elseif numel(ElecNrs) == 1
          hgexport(gcf, [imagesdir 'Depths/'  tractname '/' patient_id '_' num2str(ElecNrs)]);
        end
      end
      
      if strcmp(display, 'no')
        close % no need to see the figures
      end
      
      % Remove the electrodes that were plotted from the d_within_range list so
      % that they are not plotted again
      d_within_range(find(d_within_range(:, best_slice)), :) = 0;
    end
  end
end
if strcmp(electype, 'surface') || strcmp(electype, 'all')
  elec = {};
  
  % Limit elec to all surface elecs or the elecs for a particular grid/strip depending on the method
  if strcmp(method, 'all')
    gridnames = {};
    for n = 1:numel(elec_og.grids)
      gridnames = [gridnames; elec_og.grids{n}];
    end
    cfg = [];
    cfg.channel = gridnames;
    elec{1} = select_elec(cfg, elec_og);
    error('cfg.method = "all" is currently not supported for grids')
  elseif strcmp(method, 'ind') % create a cell array of elec structures: 1 for each grid/strip
    for n = 1:numel(elec_og.grids)
      cfg = [];
      cfg.channel = elec_og.grids{n};
      elec{n} = select_elec(cfg, elec_og);
      
%       cfg = [];
%       cfg.hullpos = hullpos;
%       elec{n} = describe_elec(cfg, elec{n});
    end
  end
  
  % Make a directory for Grid Figures if it doesn't already exist
  if ~exist([imagesdir 'Grids_and_Strips/'])
    mkdir([imagesdir 'Grids_and_Strips/']);
  end
  
  for n = 1:numel(elec)
    % Get the names and numbers of these electrodes
    ElecStrs = elec_og.grids{n}; %{};
    for x = 1:length(ElecStrs)
        ElecNrs(x) = str2double(ElecStrs{x}(4:end)); %[];
    end
%     for e = 1:numel(elec{n}.label) % electrode loop
%       ElecStrs{e,1} = regexprep(elec{n}.label{e}, '\d+(?:_(?=\d))?', ''); % without electrode numbers
%       ElecNrs(e) = str2double(regexp(elec{n}.label{e},'-?\d+\.?\d*|-?\d*\.?\d+', 'match')); % without electrode strings
%     end
    gridname = [ElecStrs{1} '_' ElecStrs{end}]; %char(unique(ElecStrs));
    
    % Make a directory for this grid if it doesn't already exist
    if ~exist([imagesdir 'Grids_and_Strips/' gridname '/'])
      mkdir([imagesdir 'Grids_and_Strips/' gridname '/']);
    end
    
    % plot the grid(s)/strip(s) and save an image from a view at the 6 major angles
    
    figure;
    if strcmp(unique(elec{n}.chanside(match_str(elec{n}.chantype, {'ieeg_strip', 'ieeg_grid'}))), 'left'); % electrodes only on left cortex
      ft_plot_mesh(cortex_lh, 'facecolor', [0.781 0.762 0.664], 'EdgeColor', 'none');
      material dull;
    elseif strcmp(unique(elec{n}.chanside(match_str(elec{n}.chantype, {'ieeg_strip', 'ieeg_grid'}))), 'right'); % electrodes only on right cortex
      ft_plot_mesh(cortex_rh, 'facecolor', [0.781 0.762 0.664], 'EdgeColor', 'none');
      material dull;
    elseif any(strcmp(unique(elec{n}.chanside(match_str(elec{n}.chantype, {'ieeg_strip', 'ieeg_grid'}))), 'right')) && ...
        any(strcmp(unique(elec{n}.chanside(match_str(elec{n}.chantype, {'ieeg_strip', 'ieeg_grid'}))), 'left'));
      % electrodes on both hemispheres
      ft_plot_mesh(cortex_rh, 'facecolor', [0.781 0.762 0.664], 'EdgeColor', 'none');
      material dull;
      ft_plot_mesh(cortex_lh, 'facecolor', [0.781 0.762 0.664], 'EdgeColor', 'none');
      material dull;
    end
    
    
    % plot the corner electrodes separately and plot them with numbers
%     if strcmp(unique(elec{n}.chantype), 'ieeg_grid')
%       corner_nums = [1 elec{n}.grid_dim(1,2) (elec{n}.grid_dim(1,1)-1)*elec{n}.grid_dim(1,2)+1 elec{n}.grid_dim(1,1)*elec{n}.grid_dim(1,2)];
%       corner_elecs = {};
%       for c = 1:numel(corner_nums)
%         corner_elecs{c} = [gridname num2str(corner_nums(c))];
%       end
%       cfg = [];
%       cfg.channel = corner_elecs';
%       elec_corners = select_elec(cfg, elec{n});
%       % NOTE: if some of the corner electrodes are missing, select_elec
%       % will ignore them, so only the corners that are present will be
%       % plotted
%       
%       % take the letters out of the labels, so there are only numbers
%       for c = 1:numel(elec_corners.label)
%         elec_corners.label{c} = elec_corners.label{c}(find(isstrprop(elec_corners.label{c}, 'digit')));
%       end
%     elseif strcmp(unique(elec{n}.chantype), 'ieeg_strip')
%       corner_nums = [1 elec{n}.grid_dim(1,2)];
%       corner_elecs = {};
%       for c = 1:numel(corner_nums)
%         corner_elecs{c} = [gridname num2str(corner_nums(c))];
%       end
%       cfg = [];
%       cfg.channel = corner_elecs';
%       elec_corners = select_elec(cfg, elec{n});
%       for c = 1:numel(corner_nums)
%         elec_corners.label{c} = num2str(corner_nums(c));
%       end
%     end
    
%     ft_plot_sens(elec_corners, 'elecsize', 1, 'style', 'w.', 'label', 'label');
    h = ft_plot_sens(elec{n}, 'elecsize', 7, 'style', 'ko');
    set(h, 'MarkerEdgeColor', 'k', 'MarkerFaceColor', 'r')
    %h = ft_plot_sens(elec{n}, 'elecsize', 20, 'style', 'w.');
    
    % right lateral
    view([90 0]); camlight; lighting gouraud;
    hgexport(gcf, [imagesdir 'Grids_and_Strips/' gridname '/' patient_id '_Right_Lateral']);
    delete(findall(gcf,'Type','light')) % shut out the lights to start fresh for next figure
    
    % left lateral
    view([-90 0]); camlight; lighting gouraud;
    hgexport(gcf, [imagesdir 'Grids_and_Strips/' gridname '/' patient_id '_Left_Lateral']);
    delete(findall(gcf,'Type','light')) % shut out the lights to start fresh for next figure
    
    % anterior
    view([180 0]); camlight; lighting gouraud;
    hgexport(gcf, [imagesdir 'Grids_and_Strips/' gridname '/' patient_id '_Anterior']);
    delete(findall(gcf,'Type','light')) % shut out the lights to start fresh for next figure
    
    % posterior
    view([0 0]); camlight; lighting gouraud;
    hgexport(gcf, [imagesdir 'Grids_and_Strips/' gridname '/' patient_id '_Posterior']);
    delete(findall(gcf,'Type','light')) % shut out the lights to start fresh for next figure
    
    % Superior
    view([0 90]); camlight; lighting gouraud;
    hgexport(gcf, [imagesdir 'Grids_and_Strips/' gridname '/' patient_id '_Superior']);
    delete(findall(gcf,'Type','light')) % shut out the lights to start fresh for next figure

    % Inferior
    view([0 -90]); camlight; lighting gouraud;
    hgexport(gcf, [imagesdir 'Grids_and_Strips/' gridname '/' patient_id '_Inferior']);
    delete(findall(gcf,'Type','light')) % shut out the lights to start fresh for next figure
    
    if strcmp(display, 'no')
      close % no need to see the figures
    end
  end
end

