function search_dicomseries(directory)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% SEARCH_DICOMSERIES searches and visualizes all DICOM files (.DCM) in a 
% directory and its subdirectories. This can be instrumental for selecting 
% the best quality scan for follow-up analysis in case there are multiple.
%
% Use as:
%   search_dicomseries(directory)
%
% Ensure FieldTrip is correcty added to the MATLAB path:
%   addpath <path to fieldtrip home directory>
%   ft_defaults
%
% This function is described in Stolk, Griffin et al. (2017)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%      


threshold = 100; % minimum number of DICOM files required for plotting

list = dir(directory);
for l = 1:numel(list) % list loop
  
  if (strcmp(list(l).name, '.') || strcmp(list(l).name, '..') || strcmp(list(l).name, '.DS_Store')) % ignore '.' and '..' cases
    continue; % skip this 'file'
  end
  
  full_directory = fullfile(directory, list(l).name);
  if isequal(list(l).isdir, 1) % recurse down
    search_dicomseries(full_directory);
  elseif isequal(list(l).isdir, 0) && numel(list)-2 > threshold % read and plot
    try
      fprintf(['>> plotting ' full_directory ' <<\n']);
      mri = ft_read_mri(full_directory); ft_sourceplot([], mri); clear mri
      title([full_directory ', ' num2str(numel(list)-2) ' dicoms']);
      drawnow
    catch
      fprintf(['>> could not plot ' full_directory ' <<\n']);
    end
    return; % use only one DICOM from each directory
  end
  
end % end of list loop
