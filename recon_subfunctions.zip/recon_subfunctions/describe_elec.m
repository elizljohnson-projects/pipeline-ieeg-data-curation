function elec_out = describe_elec(cfg, elec_in)

% --------------------------------------------------------
% DESCRIBE_ELEC automatically detects information from the electrode positions,
% including which sets of electrodes are surface grids, surface strips, or depths
% and which hemisphere they are located in
%
% Use as:
%   elec_out = id_grids(cfg, elec_in)
%   where
%     elec_in           = structure, with a .label and .chanpos field
%
%   The configuration options may contain
%     cfg.method        = 'type',       returns a 1x3 cell array of tract names detected as grids (1), strips (2), or depths (3)
%                         'lat',        returns a 1x2 cell array of tract names detected in the left (1) or right (2) hemispheres or interhemispheric (3)
%     cfg.detchantype   = 'auto' or 'manual', determines whether channel
%                         types (i.e., depths, strips, grids, should be detected automatically
%                         or manually entered)
%     cfg.orientation   = string, orientation of the coordinate system (default = 'RAS')
%     cfg.hullpos       = Nx3 array of positions on the smoothed cortical
%                         hull mesh (for identifying electrodes as surface or depths)

%
% Copyright (C) 2017, Arjen Stolk & Sandon Griffin
% --------------------------------------------------------

elec_out = elec_in;

% get the input options
cfg.method        = ft_getopt(cfg, 'method', 'type');
cfg.detchantype   = ft_getopt(cfg, 'detchantype', 'manual');
cfg.orientation   = ft_getopt(cfg, 'orientation', []);
hullpos           = ft_getopt(cfg, 'hullpos', []);

if isempty(cfg.orientation)
  warning('Orientation of coordinate system not specified, using RAS as default')
  cfg.orientation = 'RAS';
end

% extract info from label field
for e = 1:numel(elec_in.label) % electrode loop
  ElecStrs{e,1} = regexprep(elec_in.label{e}, '\d+(?:_(?=\d))?', ''); % without electrode numbers
  ElecNrs(e) = str2double(regexp(elec_in.label{e},'-?\d+\.?\d*|-?\d*\.?\d+', 'match')); % without electrode strings
end
GridDescript = unique(ElecStrs);
ngrids = numel(GridDescript);
for g = 1:ngrids % grid loop
  Grid2Elec{g} = match_str(ElecStrs, GridDescript{g}); % assign electrodes to grids
end

elec_out.surface = {};
elec_out.depths = {};
elec_out.grid_dim = NaN(ngrids, 2);
elec_out.chantype = cell(size(elec_in.label, 1), 1);
elec_out.chanside = cell(size(elec_in.label, 1), 1);

for g = 1:ngrids % grid loop
  if numel(ElecNrs(Grid2Elec{g})) < max(ElecNrs(Grid2Elec{g}))
    warning('%s has less electrodes than would be expected from the highest numbered electrode in this grid, which may lead to an incorrect output', GridDescript{g});
  end
  % determine grid dimensions
  elec_g = elec_in;
  elec_g.label = elec_in.label(Grid2Elec{g});
  elec_g.elecpos = elec_in.elecpos(Grid2Elec{g}, :);
  elec_out.grid_dim(g,1:2) = determine_griddim(elec_g);
  
  pos = elec_in.elecpos(Grid2Elec{g}, :);
  
  if strcmp(cfg.detchantype, 'auto')
    % based on grid dimensions, determine if this set of electrodes is part of a grid, strip or depth
    if elec_out.grid_dim(g,1) > 1
      % grid_names{end+1} = GridDescript{g};
      [elec_out.chantype(Grid2Elec{g})] = {'ieeg_grid'};
      elec_out.surface{end+1} = elec_out.label(Grid2Elec{g});
    elseif elec_out.grid_dim(g,1) == 1 % must be a strip or depth
      
      % Determine distance between electrodes
      d_bwelec = [];
      for e = 1:size(pos,1)-1;
        d_bwelec(e) = sqrt(sum((pos(e+1,:)-pos(e,:)).^2));
      end
      
      % Determine whether the electrode positions are modeled well with a straight line
      dx_bwelec = []; % X distance between consecutive pairs of electrodes
      dy_bwelec = []; % Y distance between consecutive pairs of electrodes
      dz_bwelec = []; % Z distance between consecutive pairs of electrodes
      for e = 1:size(pos,1)-1;
        dx_bwelec(e) = pos(e+1, 1) - pos(e, 1);
        dy_bwelec(e) = pos(e+1, 2) - pos(e, 2);
        dz_bwelec(e) = pos(e+1, 3) - pos(e, 3);
      end
      % find the average direction of this depth or strip
      r = [nanmean(dx_bwelec), nanmean(dy_bwelec), nanmean(dz_bwelec)];
      rnorm = r./sqrt(sum(r.^2));
      
      % define the origin of the predicted depth tract as the mean position
      % of the electrodes
      ori = [nanmean(pos(:,1)), nanmean(pos(:,2)), nanmean(pos(:,3))];
      
      % generate a series of closely spaced points along the linear model
      % of electrode positions
      pt_pred = [];
      pt_range = -50:50;
      for p = 1:numel(pt_range)
        pt_pred(p,:) = ori+pt_range(p)*rnorm;
      end
      
      % for each electrode, find the difference between the closest point
      % in the linear model and the actual position
      d_error = [];
      pos_pred = [];
      for e = 1:size(pos,1);
        d_error_e = [];
        for p = 1:numel(pt_range)
          d_error_e(p) = sqrt(sum((pos(e,:)-pt_pred(p,:)).^2));
        end
        d_error(e) = min(d_error_e);
      end
      
      % if there are no significant outliers in the distance between
      % consecutive pairs of electrodes AND the distance between the linear model
      % and actual electrode position never exceeds 3mm, then the
      % electrode tract is a depth.  Otherwise, it is a strip
      if any(d_error>3) || any(abs(zscore(d_bwelec, [], 2)))>2
        if numel(ElecNrs(Grid2Elec{g})) > 12
          warning('%s has fallen into the strip classification, but it has %d electrodes, which seems like too many to be on a strip, so it is being reclassified as a grid', GridDescript{g}, numel(ElecNrs(Grid2Elec{g})));
          % grid_names{end+1} = GridDescript{g};
          [elec_out.chantype(Grid2Elec{g})] = {'ieeg_grid'};
          elec_out.surface{end+1} = elec_out.label(Grid2Elec{g});
        else
          
          if ~isempty(hullpos) % if you have the hull positions, use them to confirm that this is not a depth
            d2ctx = [];
            for e = 1:length(pos);
              d2ctx_e = [];
              for n = 1:size(hullpos,1)
                d2ctx_e(end+1) = sqrt(sum((pos(e, 1:3)-hullpos(n,:)).^2));
              end
              d2ctx(e) = min(d2ctx_e); % the minimum distance from electrode E to a point on the cortical hull
            end
            
            if any(d2ctx>4)
              % depth_names{end+1} = GridDescript{g};
              [elec_out.chantype(Grid2Elec{g})] = {'ieeg_depth'};
              elec_out.depths{end+1} = elec_out.label(Grid2Elec{g});
            else
              % strip_names{end+1} = GridDescript{g};
              [elec_out.chantype(Grid2Elec{g})] = {'ieeg_strip'};
              elec_out.surface{end+1} = elec_out.label(Grid2Elec{g});
            end
            
          else
            % strip_names{end+1} = GridDescript{g};
            [elec_out.chantype(Grid2Elec{g})] = {'ieeg_strip'};
            elec_out.surface{end+1} = elec_out.label(Grid2Elec{g});
          end
        end
      elseif size(pos, 1) == 4
        % strip_names{end+1} = GridDescript{g};
        warning('%s was well modeled by a straight line, but it has 4 electrodes, which seems like too not enough to be a depth, so it is being reclassified as a strip', GridDescript{g});
        [elec_out.chantype(Grid2Elec{g})] = {'ieeg_strip'};
        elec_out.surface{end+1} = elec_out.label(Grid2Elec{g});
      elseif numel(ElecNrs(Grid2Elec{g})) > 18
        warning('%s has fallen into the depth classification, but it has %d electrodes, which seems like too many to be in a depth, so it is being reclassified as a grid', GridDescript{g}, numel(ElecNrs(Grid2Elec{g})));
        % grid_names{end+1} = GridDescript{g};
        [elec_out.chantype(Grid2Elec{g})] = {'ieeg_grid'};
        elec_out.surface{end+1} = elec_out.label(Grid2Elec{g});
      else
        % depth_names{end+1} = GridDescript{g};
        [elec_out.chantype(Grid2Elec{g})] = {'ieeg_depth'};
        elec_out.depths{end+1} = elec_out.label(Grid2Elec{g});
      end
    end % end if grid or strip/depth
  elseif strcmp(cfg.detchantype, 'manual')
    % ask user to manually enter the channel types
    chantype = input(['is ' GridDescript{g} ' a depth, strip, or grid? \n'], 's');
    elec_out.chantype(Grid2Elec{g}) = {['ieeg_' chantype]};
    if strcmp(chantype, 'depth')
      elec_out.depths{end+1} = elec_out.label(Grid2Elec{g});
      elec_out.grid_dim(g,1) = 1;
      elec_out.grid_dim(g,2) = numel(Grid2Elec{g});
    elseif strcmp(chantype, 'strip') 
      elec_out.surface{end+1} = elec_out.label(Grid2Elec{g});
      elec_out.grid_dim(g,1) = 1;
      elec_out.grid_dim(g,2) = numel(Grid2Elec{g});
    elseif strcmp(chantype, 'grid')
      elec_out.surface{end+1} = elec_out.label(Grid2Elec{g});
      if elec_out.grid_dim(g,1) == 1
        fprintf(['the automatically detected dimensions of ' GridDescript{g} ...
          '\n are one dimensional, which cannot be the case if ' GridDescript{g} ...
          '\n is a grid, so they will need to be entered manually\n']);
        elec_out.grid_dim(g,1) = str2num(input(['how many rows of electrodes are in the ' GridDescript{g} ' grid? \n'], 's'));
        elec_out.grid_dim(g,2) = str2num(input(['how many columns of electrodes are in the ' GridDescript{g} ' grid? \n'], 's'));
      end
    else 
      error([GridDescript{g} ' must be a "depth", "strip", or "grid"'])
    end
  else
    error('cfg.detchantype must be either "auto" or "manual"')
  end

  % Detect L/R
  if strcmp(cfg.orientation(1), 'R')
    if nanmean(pos(:,1)) <= 2 && nanmean(pos(:,1)) >= 0
      [elec_out.chanside(Grid2Elec{g})] = {'right-interhemispheric'};
    elseif nanmean(pos(:,1)) <= 0 && nanmean(pos(:,1)) >= -2
      [elec_out.chanside(Grid2Elec{g})] = {'left-interhemispheric'};
    elseif nanmean(pos(:,1)) > 0
      [elec_out.chanside(Grid2Elec{g})] = {'right'};
    elseif nanmean(pos(:,1)) < 0
      [elec_out.chanside(Grid2Elec{g})] = {'left'};
    end
  elseif strcmp(cfg.orientation(1), 'L')
    if nanmean(pos(:,1)) <= 2 && nanmean(pos(:,1)) >= -2
      [elec_out.chanside(Grid2Elec{g})] = {'interhemispheric'};
    elseif nanmean(pos(:,1)) < -2
      [elec_out.chanside(Grid2Elec{g})] = {'right'};
    elseif nanmean(pos(:,1)) > 2
      [elec_out.chanside(Grid2Elec{g})] = {'left'};
    end
  elseif strcmp(cfg.orientation(2), 'R')
    if nanmean(pos(:,2)) <= 2 && nanmean(pos(:,2)) >= -2
      [elec_out.chanside(Grid2Elec{g})] = {'interhemispheric'};
    elseif nanmean(pos(:,2)) > 2
      [elec_out.chanside(Grid2Elec{g})] = {'right'};
    elseif nanmean(pos(:,2)) < -2
      [elec_out.chanside(Grid2Elec{g})] = {'left'};
    end
  elseif strcmp(cfg.orientation(2), 'L')
    if nanmean(pos(:,2)) <= 2 && nanmean(pos(:,2)) >= -2
      [elec_out.chanside(Grid2Elec{g})] = {'interhemispheric'};
    elseif nanmean(pos(:,2)) < -2
      [elec_out.chanside(Grid2Elec{g})] = {'right'};
    elseif nanmean(pos(:,2)) > 2
      [elec_out.chanside(Grid2Elec{g})] = {'left'};
    end
  elseif strcmp(cfg.orientation(3), 'R')
    if nanmean(pos(:,3)) <= 2 && nanmean(pos(:,3)) >= -2
      [elec_out.chanside(Grid2Elec{g})] = {'interhemispheric'};
    elseif nanmean(pos(:,3)) > 2
      [elec_out.chanside(Grid2Elec{g})] = {'right'};
    elseif nanmean(pos(:,3)) < -2
      [elec_out.chanside(Grid2Elec{g})] = {'left'};
    end
  elseif strcmp(cfg.orientation(3), 'L')
    if nanmean(pos(:,3)) <= 2 && nanmean(pos(:,3)) >= -2
      [elec_out.chanside(Grid2Elec{g})] = {'interhemispheric'};
    elseif nanmean(pos(:,3)) < -2
      [elec_out.chanside(Grid2Elec{g})] = {'right'};
    elseif nanmean(pos(:,3)) > 2
      [elec_out.chanside(Grid2Elec{g})] = {'left'};
    end
  else
    error('cfg.orientation does not make sense.  It should be 3 letters and contain either an R or an L');
  end
end
%     output = cell(1,3);
%     output{1} = left_grids; output{2} = right_grids; output{3} = interhemi_grids;

